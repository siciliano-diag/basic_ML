from setuptools import setup

setup(
    name='basic_ML',
    packages=['basic_ML'],
    description='Basic Machine LEarning',
    version='0.0.1',
    url='https://github.com/siciliano-diag/basic_ML.git',
    author='siciliano-diag',
    author_email='siciliano@diag.uniroma1.it',
    keywords=['pip','MachineLearning']
    )