def app():
    print("¡basic_ML!")